using System;

namespace GameOverrideDemo
{
    public class Skill
  {
    protected string? skillName;
    protected float basePower;
    protected float manaCost;
    
    public Skill()
    {
        skillName = "pempek geprek";
        basePower = 10f;
        manaCost = 5f;
        Console.WriteLine("kostruktor default skill");
    }
    
    public Skill(string name, float power, float mana)
    {
          Console.WriteLine("konstruktor berparameter skill");
          skillName = name;
          basePower = power;
          manaCost = mana;
    }
    
    public virtual float CalculateDamage()
    {
        Console.WriteLine("(skill.ClculateDamage)menghitung damage dasar....");
        return basePower;
    }
    
    public void DisplaySkillInfo()
    {
        Console.WriteLine("SKILL NAME  :" + skillName);
        Console.WriteLine("BASE POWER  :" + basePower);
        Console.WriteLine("MANA COST   :" + manaCost);
    }
  }
}

