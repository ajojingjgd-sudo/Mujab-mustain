using System;

namespace GameOverrideDemo
{
   class Program
 {
    static void Main(string[] args)
    {
        Console.WriteLine("DEMO OVERRIDING [SKILL GAME]");
        
        Console.WriteLine("");
        PhysicalSkill slash = new PhysicalSkill(0.3f,"slash",50f,15f);
        slash.DisplaySkillInfo();
        float slashDamage = slash.CalculateDamage();
        Console.WriteLine("damag yang dihasilkan = " + slashDamage + "\n");
        
        Console.WriteLine("");
        MagicSkill fireBall = new MagicSkill("fire","fireball",40f,25f);
        fireBall.DisplaySkillInfo();
        float fireDamage = fireBall.CalculateDamage();
        Console.WriteLine("damag yang dihasilkan = " + fireDamage + "\n");
        
        Console.WriteLine("");
        HealSkill heal = new HealSkill(30f,"heal",50f,20f);
        heal.DisplaySkillInfo();
        float healAmount = heal.CalculateDamage();
        Console.WriteLine("damag yang dihasilkan = " + healAmount + "\n");
    }
 }
}

