using System;

namespace GameOverrideDemo
{
    public class PhysicalSkill : Skill
    {
        private float critRate;
        
        public PhysicalSkill()
        {
            critRate = 0.1f;
            Console.WriteLine("");
        }
        
        public PhysicalSkill( float critRate, string name, float power, float mana) 
         : base(name,power,mana)
         {
             Console.WriteLine("");
             this.critRate = critRate;
         }
         
         public override float CalculateDamage()
         {
             Console.WriteLine("");
             float damage = basePower *(1 + critRate);
             return damage;
         }
         
         public new void DisplaySkillInfo()
         {
             base.DisplaySkillInfo();
             Console.WriteLine("CRIT RATE   : " + (critRate * 100) + "%");
             Console.WriteLine("≠===============================≠");
         }
    }
}