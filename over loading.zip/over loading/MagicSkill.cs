using System;

namespace GameOverrideDemo
{
    public class MagicSkill : Skill
    {
        private String elementType;
        
        public MagicSkill()
        {
            elementType = "normal";
            Console.WriteLine("");
        }
        
        public MagicSkill( String elementType, string name, float power, float mana) 
         : base(name,power,mana)
         {
             Console.WriteLine("");
             this.elementType = elementType;
         }
         
         public override float CalculateDamage()
         {
             Console.WriteLine("");
             float damage = basePower;
             
             if (elementType == "fire")
             {
                 damage *= 1.5f;
                 Console.WriteLine("");
             }
             else if (elementType == "ice")
             {
                 damage *= 1.2f;
                 Console.WriteLine("");
             }
             return damage;
         }
         
         public new void DisplaySkillInfo()
         {
             base.DisplaySkillInfo();
             Console.WriteLine("ELEMENT TYPE :" +elementType);
             Console.WriteLine("===========================");
         }
    }
}