using System;

namespace GameOverrideDemo
{
    public class HealSkill : Skill
    {
        private float bonusHeal;
        
        public HealSkill()
        {
            bonusHeal = 30f;
            Console.WriteLine("");
        }
        
        public HealSkill( float bonusHeal, string name, float power, float mana) 
         : base(name,power,mana)
         {
             Console.WriteLine("");
             this.bonusHeal = bonusHeal;
         }
         
         public override float CalculateDamage()
         {
             Console.WriteLine("");
             float healAmount = basePower + bonusHeal;
             return healAmount;
         }
         
         public new void DisplaySkillInfo()
         {
             base.DisplaySkillInfo();
             Console.WriteLine("BONUS HEAL :" + bonusHeal);
             Console.WriteLine("========================");
         }
    }
}