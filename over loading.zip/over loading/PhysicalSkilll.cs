using System;

namespace GameOverrideDemo
{
    
    public class PhysicalSkill : Skill
    {
        private float critRate;
        
        public PhysicalSkill()
        {
            critRate = 0.1f;
            Console.WriteLine("");
        }
        
        public PhysicalSkill( float critRate, string name, float power, float mana) 
         : base(name,power,mana)
         {
             Console.WriteLine("");
             this.critRate = critRate;
         }
         
         
        public override float CalculateDamage()
        {
            Console.WriteLine("[PhysicalSkill.CalculateDamage] Menghitung damage fisik dengan critical hit...");
            return basePower * (1 + critRate);
        }
        
        
        
       public new void DisplaySkillInfo()
         {
             base.DisplaySkillInfo();
             Console.WriteLine("CRIT RATE   : " + (critRate * 100) + "%");
             Console.WriteLine("≠===============================≠");
         }

        public float CalculateDamage(bool isBackstab)
        {
           Console.WriteLine($"[PhysicalSkill.CalculateDamage] Menghitung damage fisik dengan backstab: {isBackstab}");

           float damage = basePower * (1 + critRate);

           if (isBackstab)
            damage *= 1.5f;

           return damage;
        
        }
    }
}
   
